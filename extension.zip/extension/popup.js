document.addEventListener('DOMContentLoaded', () => {
  const titleInput = document.getElementById('title');
  const urlInput = document.getElementById('url');
  const tagsInput = document.getElementById('tags');
  const saveBtn = document.getElementById('saveBtn');

  // Grab the active tab's info
  chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
    if (tabs[0]) {
      titleInput.value = tabs[0].title || '';
      urlInput.value = tabs[0].url || '';
    }
  });

  saveBtn.addEventListener('click', () => {
    if (!urlInput.value) return;

    const title = encodeURIComponent(titleInput.value);
    const url = encodeURIComponent(urlInput.value);
    const tags = encodeURIComponent(tagsInput.value);
    
    saveBtn.textContent = 'Saving...';
    saveBtn.style.opacity = '0.8';
    
    // Use a hidden iframe to load Link Manager and trigger the autosave logic
    // This allows silent saving to local storage without opening a new tab
    const iframe = document.createElement('iframe');
    iframe.style.display = 'none';
    iframe.src = `http://127.0.0.1:5500/index.html?url=${url}&title=${title}&tags=${tags}&autosave=true`;
    
    document.body.appendChild(iframe);
    
    // Give it 1 second to load and save to localStorage, then close popup
    setTimeout(() => {
      saveBtn.textContent = 'Saved!';
      setTimeout(() => {
        window.close();
      }, 500);
    }, 1000);
  });
});
